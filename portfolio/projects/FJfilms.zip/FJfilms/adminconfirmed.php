<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "FJdb";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if user ID is provided
if(isset($_GET['id'])) {
    $id = $_GET['id'];
    
    // Retrieve user information
    $sql = "SELECT * FROM users WHERE id=$id";
    $result = $conn->query($sql);
    
    if ($result->num_rows > 0) {
        // Fetch user data
        $row = $result->fetch_assoc();
        
        // Insert user data into user_confirmed table
        $insert_sql = "INSERT INTO user_confirmed (name, contact_number, address, email, date, picture) 
                    VALUES ('".$row['name']."', '".$row['contact_number']."', '".$row['address']."', '".$row['email']."', '".$row['date']."', '".$row['picture']."')";
        if ($conn->query($insert_sql) === TRUE) {
            // User confirmed and inserted into user_confirmed table, now delete from users table
            $delete_sql = "DELETE FROM users WHERE id=$id";
            if ($conn->query($delete_sql) === TRUE) {
                // Display a success message with a popup
                echo "<script>
                        alert('User confirmed and moved to confirmed users table successfully.');
                        window.location.href = 'admin.php'; // Redirect to admin.php
                      </script>";
            } else {
                echo "Error deleting record: " . $conn->error;
            }
        } else {
            echo "Error: " . $insert_sql . "<br>" . $conn->error;
        }
    } else {
        echo "User not found.";
    }
} else {
    echo "User ID not provided.";
}

// Close the database connection after use
$conn->close();
?>

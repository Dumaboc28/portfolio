<?php
session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Check your admin credentials (replace these with your actual admin credentials)
    $admin_username = "admin";
    $admin_password = "admin123";

    $input_username = $_POST['username'];
    $input_password = $_POST['password'];

    if ($input_username == $admin_username && $input_password == $admin_password) {
        $_SESSION['admin_logged_in'] = true;
        header("Location: admin.php");
        exit();
    } else {
        $error_message = "Invalid credentials. Please try again.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport"content="width=device-width,
    initial-scale=1.0">
    <title>Login Form in HTML and CSS | Codehal</title>
    <link rel="stylesheet" href="Login.css">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>


</head>
<body>
    <div class="wrapper">
        <form action="" method="post">
            <h1>Login</h1>
            <div class="input-box">
                <input type="text" placeholder="Username" required name="username">
                <i class='bx bxs-user'></i>
            </div>
        <div class="input-box">
            <input type="password" placeholder="Password" required name="password">
            <i class='bx bxs-lock-alt'></i>
            </div>
            <div class="remember-forgot">
                <label><input type="checkbox">Remember me</label>
                <a href="#">Forgot Password?</a>
            </div>
            <button type="submit" class="BTN">Log In</button>
        </form>
    </div>
</body>
<!DOCTYPE html>
<html>
<head>
    <title>Event Management -FJFILMS</title>
    <link rel="stylesheet" type="text/css" href="admin.css">
    <style>
        /* CSS for zoomed image */
        .modal {
            display: none;
            position: fixed;
            z-index: 1;
            padding-top: 100px;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            overflow: auto;
            background-color: rgb(0,0,0);
            background-color: rgba(0,0,0,0.9);
        }

        .modal-content {
            margin: auto;
            display: block;
            width: 80%;
            max-width: 700px;
        }

        #img01 {
            width: 100%;
        }

        .close {
            position: absolute;
            top: 15px;
            right: 35px;
            color: #f1f1f1;
            font-size: 40px;
            font-weight: bold;
            transition: 0.3s;
        }

        .close:hover,
        .close:focus {
            color: #bbb;
            text-decoration: none;
            cursor: pointer;
        }

        /* CSS for image hover effect */
        .zoom-effect:hover {
            transform: scale(3.0); /* Scale the image by 110% on hover */
            transition: transform 0.3s ease; /* Smooth transition effect */
        }
        .no-events {
    font-style: italic;
    color: #999; /* Adjust color as needed */
    font-size: 50px; /* Adjust font size as needed */
    margin-top: 20px; /* Add some margin for spacing */
}
.no-events-container {
    display: flex;
    align-items: center; /* Vertically center the content */
    flex-direction: column; /* Stack items vertically */
    height: 100vh; /* Set height of container to viewport height */

}

.image-container {
    margin-top: 20px; /* Adjust as needed */
    margin-bottom: 20px;
}

    </style>
</head>
<body>

<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "FJdb";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch users
$sql = "SELECT * FROM users";
$result = $conn->query($sql);

// Display users table
if ($result->num_rows > 0) {
    echo "<h2>Pending Events</h2>";
    echo "<table class='border'>";
    echo "<tr><th>Name</th><th>Mobile Number</th><th>Address</th><th>Email</th><th>Date</th><th>Payment</th><th>Action</th></tr>";
    while($row = $result->fetch_assoc()) {
        echo "<tr>";
        echo "<td>" . $row["name"] . "</td>";
        echo "<td>" . $row["contact_number"] . "</td>";
        echo "<td>" . $row["address"] . "</td>";
        echo "<td>" . $row["email"] . "</td>";
        echo "<td>" . $row["date"] . "</td>";
        echo "<td><img src='uploads/" . $row['picture'] . "' width='200' class='zoom-effect' onclick='openModal(this)'></td>";
        echo "<td class='action-links'><a href='adminconfirmed.php?id=" . $row["id"] . "'>Confirm</a> | <a href='admindelete.php?id=" . $row["id"] . "'>Delete</a></td>";
        echo "</tr>";
    }
    echo "</table>";
} else {
    echo "<div class='no-events-container'>";
    echo "<div class='image-container'>";
    echo "<img src='image/pending.jpg' style='width: 1200px; height: auto;' >";
    echo "</div>";
 
}

// Close the table
echo "<br><br>";

// Display confirmed users
$sql_confirmed = "SELECT * FROM user_confirmed";
$result_confirmed = $conn->query($sql_confirmed);

if ($result_confirmed->num_rows > 0) {
    echo "<h2>Confirmed Events Information</h2>";
    echo "<table class='border'>";
    echo "<tr><th>Name</th><th>Mobile Number</th><th>Address</th><th>Email</th><th>Date</th><th>Payment</th></tr>";
    while($row_confirmed = $result_confirmed->fetch_assoc()) {
        echo "<tr>";
        echo "<td>" . $row_confirmed["name"] . "</td>";
        echo "<td>" . $row_confirmed["contact_number"] . "</td>";
        echo "<td>" . $row_confirmed["address"] . "</td>";
        echo "<td>" . $row_confirmed["email"] . "</td>";
        echo "<td>" . $row_confirmed["date"] . "</td>";
        echo "<td><img src='uploads/" . $row_confirmed['picture'] . "' width='200' class='zoom-effect' onclick='openModal(this)'></td>";
        echo "</tr>";
    }
    echo "</table>";
} else {
    echo "<div class='no-events-container'>";
    echo "<div class='image-container'>";
    echo "<img src='image/event.jpg' style='width: 1200px; height: auto;' >";
    echo "</div>";

}

// Close connection
$conn->close();
?>

<!-- The Modal -->
<div id="myModal" class="modal">
  <span class="close" onclick="closeModal()">&times;</span>
  <img class="modal-content" id="img01">
</div>

<script>
// JavaScript function to open modal and display zoomed image
function openModal(imgElement) {
    var modal = document.getElementById("myModal");
    var modalImg = document.getElementById("img01");
    modal.style.display = "block";
    modalImg.src = imgElement.src;
}

// JavaScript function to close modal
function closeModal() {
    var modal = document.getElementById("myModal");
    modal.style.display = "none";
}
</script>

</body>
</html>



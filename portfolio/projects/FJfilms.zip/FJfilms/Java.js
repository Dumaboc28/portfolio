document.addEventListener('DOMContentLoaded', function() {
    const summaryElement = document.querySelector('.Button1','.Button2','.Button3','.Button4')
    const lastPage = document.querySelector('#Why','#Photo-Packages','#PnV-Packages','FAQs');

    

    summaryElement.addEventListener('click', function() {
        lastPage.scrollIntoView({ behavior: 'smooth' });
    });
});
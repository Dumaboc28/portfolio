<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "FJdb";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['name'];
    $contact_number = $_POST['contact_number']; // Update here to match your form field name
    $address = $_POST['address']; // Add address field
    $email = $_POST['email']; // Add email field
    $date = $_POST['date']; // Add date of birth field
    
    // Handle picture upload
   
    if ($conn->query($sql) === TRUE) {
        // Record saved successfully
        echo "<script>
                alert('New record created successfully');
                window.location.href = 'Payment.html'; // Redirect to index.html
              </script>";
    } else {
        // Error occurred
        echo "<script>
                alert('Error: " . $sql . "\\n" . $conn->error . "');
                window.location.href = 'Payment.html'; // Redirect to index.html
              </script>";
    }
} else {
    // Redirect if accessed directly without form submission
    header("Location: Payment.html");
    exit();
}

$conn->close();
?>

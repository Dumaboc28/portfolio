<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "FJdb";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if(isset($_GET['id'])) {
    $id = $_GET['id'];
    
    // Delete user from users table
    $sql = "DELETE FROM users WHERE id=$id";
    
    if ($conn->query($sql) === TRUE) {
        // Redirect to admin.php
        header("Location: admin.php");
        exit(); // Make sure to stop script execution after redirection
    } else {
        echo "Error deleting record: " . $conn->error;
    }
} else {
    echo "User ID not provided.";
}

// Close the database connection after use
$conn->close();
?>
